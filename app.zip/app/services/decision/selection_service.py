"""
C.3.5 — Technical Selection Service
----------------------------------
Responsibility:
- Build group context from existing repos
- Select baseline technique deterministically
- Produce selection trace for audit / explain

NO decision logic here
NO rule evaluation here
"""

from typing import Dict, Any, List, Optional

from app.repositories.case_line_item_repo import CaseLineItemRepository
from app.repositories.case_evidence_group_repo import CaseEvidenceGroupRepository
from app.repositories.case_evidence_repo import CaseEvidenceRepository
from app.repositories.case_fact_repo import CaseFactRepository

from app.services.policy.registry import PolicyRegistry
from app.services.policy.resolver import resolve_domain_policy


class SelectionService:
    def __init__(self):
        # BaseRepository initializes Supabase client internally in your codebase
        self.case_line_repo = CaseLineItemRepository()
        self.group_repo = CaseEvidenceGroupRepository()
        self.evidence_repo = CaseEvidenceRepository()
        self.fact_repo = CaseFactRepository()

    # =====================================================
    # Public API
    # =====================================================
    def select_for_case(self, case_id: str, domain_code: str) -> Dict[str, Any]:
        policy = PolicyRegistry.get()
        resolved_policy = resolve_domain_policy(policy, domain_code)

        # policy meta default currency (fallback)
        currency_default = getattr(policy, "meta", None)
        currency_default = getattr(currency_default, "currency_default", None) or "THB"

        # 1) Load PO snapshot (immutable)
        po_lines = self.case_line_repo.list_by_case(case_id)
        po_index = self._index_po_lines(po_lines)

        # 2) Load evidence groups
        groups = self.group_repo.list_by_case(case_id)

        results: List[Dict[str, Any]] = []
        for group in groups:
            group_ctx = self._build_group_context(
                case_id=case_id,
                domain_code=domain_code,
                group=group,
                po_index=po_index,
                currency_default=currency_default,
            )

            selection = self._select_for_group(
                group_ctx=group_ctx,
                resolved_policy=resolved_policy,
            )
            results.append(selection)

        return {"case_id": case_id, "domain": domain_code, "groups": results}

    # =====================================================
    # Core Selection Logic
    # =====================================================
    def _select_for_group(self, group_ctx: Dict[str, Any], resolved_policy) -> Dict[str, Any]:
        profile = resolved_policy.profile
        techniques = resolved_policy.techniques

        trace: List[Dict[str, Any]] = []
        selected = None

        # Hard rule: UNGROUPED never attempts baseline selection
        if group_ctx["group_key_text"] == "UNGROUPED":
            selected = self._fallback_selection()
            trace.append(selected)
            return self._build_group_result(group_ctx, selected, trace)

        for tech_id in profile.baseline_priority:
            tech = techniques.get(tech_id)
            if not tech:
                continue

            eval_result = self._evaluate_technique(group_ctx, tech)
            trace.append(eval_result)

            if eval_result["passed"]:
                selected = eval_result
                break

        if selected is None:
            selected = self._fallback_selection()
            trace.append(selected)

        return self._build_group_result(group_ctx, selected, trace)

    def _fallback_selection(self) -> Dict[str, Any]:
        return {
            "technique_id": "T_NO_BASELINE_ESCALATE",
            "passed": True,
            "baseline": None,
            "baseline_source": None,
            "fail_reasons": [],
            "references": {},
        }

    def _build_group_result(
        self,
        group_ctx: Dict[str, Any],
        selected: Dict[str, Any],
        trace: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        readiness = self._build_readiness_flags(group_ctx, selected)

        # expose group keys as stored in DB (text)
        gk = group_ctx.get("group_key_text")
        sk = group_ctx.get("semantic_key_text")

        return {
            "group_id": group_ctx["group_id"],
            "group_key": {
                "sku": gk if isinstance(gk, str) and gk.startswith("SKU:") else None,
                "name": sk if isinstance(sk, str) and sk.startswith("NAME:") else None,
            },
            "selected_technique": selected["technique_id"],
            "baseline": selected["baseline"],
            "baseline_source": selected["baseline_source"],
            "readiness_flags": readiness,
            "selection_trace": trace,
        }

    # =====================================================
    # Technique Evaluation
    # =====================================================
    def _evaluate_technique(self, group_ctx: Dict[str, Any], tech) -> Dict[str, Any]:
        fail_reasons: List[str] = []

        # Domain guard
        if getattr(tech, "domain", None) and tech.domain != group_ctx["domain"]:
            return self._fail_tech(tech.id, ["DOMAIN_MISMATCH"])

        # Required facts (by fact_type)
        for fact_type in getattr(tech, "required_facts", []) or []:
            if fact_type not in group_ctx["facts"]:
                fail_reasons.append(f"MISSING_FACT:{fact_type}")

        if fail_reasons:
            return self._fail_tech(tech.id, fail_reasons)

        # Gates
        gates = getattr(tech, "gates", None) or {}
        gate_failures = self._check_gates(group_ctx, gates)
        if gate_failures:
            return self._fail_tech(tech.id, gate_failures)

        # Derive baseline
        if getattr(tech, "category", None) == "BASELINE":
            derive_cfg = getattr(tech, "derive", None) or {}
            baseline_result = self._derive_baseline(group_ctx, derive_cfg)
            if not baseline_result["passed"]:
                return self._fail_tech(tech.id, baseline_result["fail_reasons"])

            return {
                "technique_id": tech.id,
                "passed": True,
                "baseline": baseline_result["baseline"],
                "baseline_source": baseline_result["baseline_source"],
                "fail_reasons": [],
                "references": baseline_result["references"],
            }

        # fallback-like technique
        return {
            "technique_id": tech.id,
            "passed": True,
            "baseline": None,
            "baseline_source": None,
            "fail_reasons": [],
            "references": {},
        }

    # =====================================================
    # Gates & Derivation
    # =====================================================
    def _check_gates(self, group_ctx: Dict[str, Any], gates: Dict[str, Any]) -> List[str]:
        reasons: List[str] = []

        # confidence gate (PRICE evidence)
        if "min_confidence" in gates:
            cfg = gates["min_confidence"] or {}
            threshold = float(cfg.get("threshold", 0) or 0)
            et = cfg.get("evidence_type", "PRICE")

            evids = group_ctx.get("evidences") or []
            typed = [e for e in evids if e.get("evidence_type") == et]

            if not typed:
                reasons.append(f"MISSING_EVIDENCE:{et}")
            else:
                best = max(typed, key=lambda x: float(x.get("confidence", 0) or 0))
                if float(best.get("confidence", 0) or 0) < threshold:
                    reasons.append(f"EVIDENCE_CONFIDENCE_BELOW_THRESHOLD:{best.get('confidence')}")

        # currency gate (IMPORTANT FIX)
        # If PO currency missing but baseline/fact currency exists -> allow.
        if gates.get("currency_match") is True:
            po_ccy = (group_ctx.get("po_line") or {}).get("unit_price", {}).get("currency")
            fact_ccy = self._best_fact_currency(group_ctx)  # from any available fact in this group
            if not po_ccy and not fact_ccy:
                reasons.append("CURRENCY_MISSING_BOTH_PO_AND_FACT")

        return reasons

    def _best_fact_currency(self, group_ctx: Dict[str, Any]) -> Optional[str]:
        facts = group_ctx.get("facts") or {}
        for _, f in facts.items():
            vj = (f.get("value_json") or {})
            ccy = vj.get("currency")
            if ccy:
                return ccy
        return None

    def _derive_baseline(self, group_ctx: Dict[str, Any], derive_cfg: Dict[str, Any]) -> Dict[str, Any]:
        fact_type = derive_cfg.get("baseline_from")
        method_required = derive_cfg.get("method_required")

        fact = (group_ctx.get("facts") or {}).get(fact_type)
        if not fact:
            return self._fail_derivation(f"MISSING_FACT:{fact_type}")

        value_json = fact.get("value_json") or {}
        value = value_json.get("price")
        if value is None:
            return self._fail_derivation("PRICE_VALUE_MISSING")

        if method_required and value_json.get("method") != method_required:
            return self._fail_derivation("FACT_METHOD_MISMATCH")

        # Currency precedence:
        # 1) fact.value_json.currency
        # 2) po_line.unit_price.currency
        # 3) policy meta default
        currency = (
            value_json.get("currency")
            or (group_ctx.get("po_line") or {}).get("unit_price", {}).get("currency")
            or group_ctx.get("currency_default")
        )

        return {
            "passed": True,
            "baseline": {"value": value, "currency": currency},
            "baseline_source": {"fact_type": fact_type, "method": value_json.get("method")},
            "references": {
                "fact_ids": [fact.get("fact_id")],
                "evidence_ids": fact.get("source_evidence_ids", []) or [],
            },
            "fail_reasons": [],
        }

    # =====================================================
    # Readiness Flags
    # =====================================================
    def _build_readiness_flags(self, group_ctx: Dict[str, Any], selected: Dict[str, Any]) -> Dict[str, bool]:
        po_ccy = (group_ctx.get("po_line") or {}).get("unit_price", {}).get("currency")
        fact_ccy = self._best_fact_currency(group_ctx)
        return {
            "baseline_available": selected.get("baseline") is not None,
            "evidence_present": len(group_ctx.get("evidences") or []) > 0,
            "currency_present": bool(po_ccy or fact_ccy),
            "po_line_found": (group_ctx.get("po_line") or {}).get("unit_price", {}).get("value") is not None
                            or (group_ctx.get("po_line") or {}).get("unit_price", {}).get("currency") is not None,
        }

    # =====================================================
    # Context Builders
    # =====================================================
    def _build_group_context(
        self,
        case_id: str,
        domain_code: str,
        group: Dict[str, Any],
        po_index: Dict[str, Dict[str, Any]],
        currency_default: str,
    ) -> Dict[str, Any]:
        group_id = group["group_id"]

        # evidences by group_id (your evidences table has group_id column)
        evidences = self.evidence_repo.list_by_group(group_id)

        # FACTS: your repository is case_id + fact_key (LOCK)
        # use group_key as primary, semantic_key as fallback
        group_key_text = group.get("group_key") or ""
        semantic_key_text = group.get("semantic_key") or ""

        facts = self._load_facts_for_group(case_id, group_key_text, semantic_key_text)
        fact_map = {f["fact_type"]: f for f in facts}

        po_line = self._resolve_po_line(group_key_text, semantic_key_text, po_index)

        return {
            "case_id": case_id,
            "domain": domain_code,
            "group_id": group_id,
            "group_key_text": group_key_text,
            "semantic_key_text": semantic_key_text,
            "po_line": po_line,
            "evidences": evidences,
            "facts": fact_map,
            "currency_default": currency_default,
        }

    def _load_facts_for_group(self, case_id: str, group_key_text: str, semantic_key_text: str) -> List[dict]:
        out: List[dict] = []

        if group_key_text:
            out.extend(self.fact_repo.list_by_group(case_id=case_id, fact_key=group_key_text))

        # fallback only if different key
        if semantic_key_text and semantic_key_text != group_key_text:
            out.extend(self.fact_repo.list_by_group(case_id=case_id, fact_key=semantic_key_text))

        # de-dup by fact_id
        seen = set()
        uniq = []
        for f in out:
            fid = f.get("fact_id")
            if fid and fid in seen:
                continue
            if fid:
                seen.add(fid)
            uniq.append(f)
        return uniq

    def _resolve_po_line(self, group_key_text: str, semantic_key_text: str, po_index: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        # Attempt keys in deterministic order:
        # 1) exact group_key (e.g., "SKU:OFF-PAP-A4")
        # 2) stripped SKU (e.g., "OFF-PAP-A4")
        # 3) semantic key exact / stripped similarly

        candidates: List[str] = []

        if group_key_text:
            candidates.append(group_key_text)
            if group_key_text.startswith("SKU:"):
                candidates.append(group_key_text.replace("SKU:", ""))

        if semantic_key_text:
            candidates.append(semantic_key_text)
            if semantic_key_text.startswith("SKU:"):
                candidates.append(semantic_key_text.replace("SKU:", ""))

        for key in candidates:
            if key in po_index:
                return po_index[key]

        # deterministic fallback
        stripped = group_key_text.replace("SKU:", "") if isinstance(group_key_text, str) else None
        return {
            "sku": stripped,
            "name": None,
            "unit_price": {"value": None, "currency": None},
            "total_price": {"value": None, "currency": None},
        }

    def _index_po_lines(self, po_lines: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """
        po_lines from CaseLineItemRepository are already canonical:
          {
            "sku": "...",
            "name": "...",
            "unit_price": {"value": ..., "currency": ...},
            ...
          }

        Index keys:
          - sku
          - "SKU:{sku}"
          - name (optional)
        """
        index: Dict[str, Dict[str, Any]] = {}

        for line in po_lines or []:
            sku = line.get("sku")
            name = line.get("name")

            # Ensure canonical shape exists even if upstream changes
            unit_price = line.get("unit_price") or {}
            if not isinstance(unit_price, dict):
                unit_price = {"value": line.get("unit_price"), "currency": line.get("currency")}
            line["unit_price"] = {
                "value": unit_price.get("value"),
                "currency": unit_price.get("currency"),
            }

            total_price = line.get("total_price") or {}
            if not isinstance(total_price, dict):
                total_price = {"value": line.get("total_price"), "currency": line.get("currency")}
            line["total_price"] = {
                "value": total_price.get("value"),
                "currency": total_price.get("currency"),
            }

            if sku:
                index[sku] = line
                index[f"SKU:{sku}"] = line

            if name:
                index[name] = line

        return index

    # =====================================================
    # Helpers
    # =====================================================
    def _fail_tech(self, tech_id: str, reasons: List[str]) -> Dict[str, Any]:
        return {
            "technique_id": tech_id,
            "passed": False,
            "baseline": None,
            "baseline_source": None,
            "fail_reasons": reasons,
            "references": {},
        }

    def _fail_derivation(self, reason: str) -> Dict[str, Any]:
        return {
            "passed": False,
            "baseline": None,
            "baseline_source": None,
            "references": {},
            "fail_reasons": [reason],
        }
