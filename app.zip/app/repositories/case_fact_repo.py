from app.repositories.base import BaseRepository
from typing import List
from datetime import datetime


class CaseFactRepository(BaseRepository):
    TABLE = "dcc_case_facts"

    # =====================================================
    # WRITE
    # =====================================================
    def upsert_fact(self, payload: dict) -> dict:
        # --- required fields (LOCKED, enterprise-grade) ---
        required = [
            "case_id",
            "group_id",          # ✅ REQUIRED
            "fact_type",
            "fact_key",
            "confidence",
            "derivation_method",
            "created_by",
        ]

        for k in required:
            if k not in payload:
                raise ValueError(f"Missing required fact field: {k}")

        payload.setdefault("created_at", datetime.utcnow().isoformat())

        # ✅ conflict must be group-scoped
        res = (
            self.sb
            .table(self.TABLE)
            .upsert(
                payload,
                on_conflict="group_id,fact_type"
            )
            .execute()
        )

        return res.data[0] if res.data else {}

    # =====================================================
    # READ
    # =====================================================
    def list_by_case(self, case_id: str) -> List[dict]:
        """
        Debug / admin only
        NOT used by decision logic
        """
        res = (
            self.sb
            .table(self.TABLE)
            .select("*")
            .eq("case_id", case_id)
            .execute()
        )
        return res.data or []

    def list_by_group(
        self,
        case_id: str = None,
        fact_key: str = None
    ) -> List[dict]:
        """
        Fetch facts by (case_id + fact_key)

        Used by:
        - C.3.5 Technical Selection
        - C.4 Decision Run
        """

        if not case_id or not fact_key:
            raise ValueError("list_by_group requires case_id and fact_key")

        res = (
            self.sb
            .table(self.TABLE)
            .select("*")
            .eq("case_id", case_id)
            .eq("fact_key", fact_key)
            .execute()
        )
        return res.data or []

