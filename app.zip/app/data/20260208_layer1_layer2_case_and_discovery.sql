BEGIN;

-- =====================================================
-- LAYER 2 — CASE SNAPSHOT (ALTER EXISTING TABLE)
-- =====================================================

-- 1. Add Unit of Measure + ERP Line Reference
ALTER TABLE dcc_case_line_items
ADD COLUMN IF NOT EXISTS uom TEXT,
ADD COLUMN IF NOT EXISTS source_line_ref TEXT;

-- Index for case lookup (defensive, even if already exists)
CREATE INDEX IF NOT EXISTS idx_case_line_items_case_id
ON dcc_case_line_items (case_id);

-- Index for item-based analytics (median / history)
CREATE INDEX IF NOT EXISTS idx_case_line_items_item_name
ON dcc_case_line_items (item_name);

-- Fast path for SKU matching
CREATE INDEX IF NOT EXISTS idx_case_line_items_sku
ON dcc_case_line_items (sku)
WHERE sku IS NOT NULL;

-- =====================================================
-- LAYER 3 — DOCUMENT DISCOVERY (NEW TABLE)
-- =====================================================

CREATE TABLE IF NOT EXISTS dcc_case_document_links (
    link_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- Anchors
    case_id TEXT NOT NULL,
    document_id UUID NOT NULL,

    -- Discovery state
    link_status TEXT NOT NULL
        CHECK (link_status IN ('INFERRED', 'CONFIRMED', 'REMOVED')),

    -- Inference metadata
    inferred_by TEXT
        CHECK (inferred_by IN ('RELATIONAL', 'VECTOR')),

    match_score NUMERIC,
    match_explain_json JSONB,

    -- Human confirmation
    confirmed_by TEXT,
    confirmed_at TIMESTAMPTZ,

    -- Timestamps
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Constraints
    CONSTRAINT fk_case_document_links_case
        FOREIGN KEY (case_id)
        REFERENCES dcc_cases(case_id)
        ON DELETE CASCADE,

    CONSTRAINT fk_case_document_links_document
        FOREIGN KEY (document_id)
        REFERENCES dcc_documents(document_id)
        ON DELETE CASCADE,

    -- One active link per case+document
    CONSTRAINT uq_case_document_unique
        UNIQUE (case_id, document_id)
);

-- Indexes for discovery + decision usage
CREATE INDEX IF NOT EXISTS idx_case_document_links_case
ON dcc_case_document_links (case_id);

CREATE INDEX IF NOT EXISTS idx_case_document_links_status
ON dcc_case_document_links (case_id, link_status);

CREATE INDEX IF NOT EXISTS idx_case_document_links_document
ON dcc_case_document_links (document_id);

COMMIT;
